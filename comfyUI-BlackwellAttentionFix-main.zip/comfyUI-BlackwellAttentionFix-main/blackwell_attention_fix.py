import logging
import torch
import comfy.model_management as model_management
import comfy.ldm.modules.attention as comfy_attention

def is_blackwell():
    if not torch.cuda.is_available():
        return False
    major, _ = torch.cuda.get_device_capability(0)
    return major >= 12


def _get_comfy_pytorch_attention():
    if hasattr(comfy_attention, "attention_pytorch"):
        return comfy_attention.attention_pytorch
    if hasattr(comfy_attention, "attention_basic"):
        return comfy_attention.attention_basic
    raise RuntimeError("Could not find attention_pytorch / attention_basic in comfy.ldm.modules.attention")


def _patch_everywhere(fn):
    """Replace every known attention entry point with the given function."""
    model_management.XFORMERS_IS_AVAILABLE = False
    if hasattr(model_management, "XFORMERS_ENABLED"):
        model_management.XFORMERS_ENABLED = False

    comfy_attention.optimized_attention        = fn
    comfy_attention.optimized_attention_masked = fn
    comfy_attention.attention_xformers         = fn

    # Modules that captured the name at import time
    for mod_name in (
        "comfy.ldm.krea2.model",
        "comfy.ldm.modules.diffusionmodules.model",
        "comfy.ldm.modules.diffusionmodules.openaimodel",
    ):
        try:
            import importlib
            mod = importlib.import_module(mod_name)
            if hasattr(mod, "optimized_attention_masked"):
                setattr(mod, "optimized_attention_masked", fn)
            if hasattr(mod, "optimized_attention"):
                setattr(mod, "optimized_attention", fn)
            if "krea2" in mod_name:
                logging.info("[BlackwellAttentionFix] Patched %s", mod_name)
        except Exception:
            pass


def apply_pytorch_fix():
    fn = _get_comfy_pytorch_attention()
    logging.info("[BlackwellAttentionFix] Switching to ComfyUI native %s", fn.__name__)
    _patch_everywhere(fn)
    logging.info("[BlackwellAttentionFix] Attention entry points now use PyTorch SDPA")


class BlackwellAttentionFix:
    """
    Optional runtime fix for the xformers
    "No operator found for memory_efficient_attention_forward"
    crash on NVIDIA Blackwell (RTX 50-series).

    Modes
    -----
    bypass   – do nothing (safe default for shared workflows / non-Blackwell GPUs)
    pytorch  – force ComfyUI native attention_pytorch (fixes the crash on 5090/5080/5070)

    Place after any model / UNET loader. Safe to leave in a workflow permanently.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "mode": (
                    ["bypass", "pytorch"],
                    {
                        "default": "bypass",
                        "tooltip": (
                            "bypass  = do nothing (default, safe for any GPU / shared workflows)\n"
                            "pytorch = force native PyTorch attention (use on RTX 50-series to fix xformers crash)"
                        ),
                    },
                ),
            }
        }

    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("model",)
    FUNCTION = "patch"
    CATEGORY = "model_patches"
    DESCRIPTION = (
        "Optional Blackwell (RTX 50xx) attention fix. "
        "Default mode is bypass so the node can stay in any workflow. "
        "Set to pytorch only when you need to avoid the xformers crash."
    )

    def patch(self, model, mode="bypass"):
        if mode == "bypass":
            logging.info("[BlackwellAttentionFix] mode=bypass – no changes")
            return (model,)

        # mode == "pytorch"
        if not is_blackwell():
            logging.info(
                "[BlackwellAttentionFix] mode=pytorch but GPU is not Blackwell – leaving attention unchanged"
            )
            return (model,)

        logging.info("[BlackwellAttentionFix] mode=pytorch + Blackwell GPU detected")
        apply_pytorch_fix()
        return (model,)


NODE_CLASS_MAPPINGS = {
    "BlackwellAttentionFix": BlackwellAttentionFix,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "BlackwellAttentionFix": "Blackwell Attention Fix (RTX 50xx)",
}
