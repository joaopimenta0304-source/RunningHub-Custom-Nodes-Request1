# comfyUI-BlackwellAttentionFix
Prevents the common xformers crash on NVIDIA Blackwell GPUs (RTX 5090 / 5080 / 5070) when using Krea2 Identity Edit
**Blackwell Attention Fix (RTX 50xx)**

### Overview
Runtime ComfyUI node that prevents the common xformers crash on NVIDIA Blackwell GPUs (RTX 5090 / 5080 / 5070):

```
NotImplementedError: No operator found for `memory_efficient_attention_forward`
… requires device with capability ≤ (9, 0) but your GPU has capability (12, 0) (too new)
```

It works by redirecting ComfyUI’s attention entry points to the built-in `attention_pytorch` (SDPA) implementation, which is fully compatible with compute capability 12.0.

### Modes

| Mode | Behaviour |
|------|-----------|
| **bypass** (default) | No-op. Model passes through unchanged. Safe for any GPU and shared workflows. |
| **pytorch** | Forces native PyTorch attention. Only applies the change when a Blackwell GPU is detected. |

### Installation
1. Create folder  
   `ComfyUI/custom_nodes/ComfyUI-BlackwellAttentionFix/`
2. Place inside it:
   - `__init__.py` (simple import of the node mappings)
   - `blackwell_attention_fix.py` (this node)
3. Restart ComfyUI.

### Usage
- Insert the node **immediately after** any model / UNET / Krea2 loader and **before** samplers or attention-heavy custom nodes.
- On RTX 50-series + Krea2 (or any model that triggers the xformers error) → set **mode = pytorch**.
- On all other systems or shared workflows → leave **mode = bypass**.

The node can stay permanently in a workflow; with `bypass` it never interferes with xformers, SageAttention, or other people’s setups.

### What it patches
- `comfy.ldm.modules.attention.optimized_attention`
- `optimized_attention_masked`
- `attention_xformers`
- Direct imports captured at load time (notably `comfy.ldm.krea2.model`)

### Compatibility
- Works with Krea2 / krea2edit, Flux, SDXL, SD1.5, Wan, LTX and most other models that go through ComfyUI’s standard attention path.
- Does **not** require launch flags (`--disable-xformers`, etc.).
- Does **not** uninstall or break xformers; it only redirects the active functions for the current process when enabled.

### Limitations
- VAE may still log “Using xformers attention” — this is harmless and separate from the diffusion attention path that was crashing.
- Performance is native PyTorch SDPA (usually close to xformers on Blackwell). SageAttention is not used by this node.
- Extremely rare custom nodes that hard-code their own xformers calls are not covered.

### License / Status
Community utility node. No external dependencies beyond ComfyUI + PyTorch.


---

##Usage in Workflows:

# 🚫 This node is purely for the **RTX 50xx** users. All other users can delete it

This solves the clash with the LoRA and nodes being built on an older system. 
- *"error. no operator found..."*


 The custom node is in the folder file with this program. Place it here:

```
📂 ComfyUI/
├── 📂 custom_nodes
│   ├── 📂 ComfyUI-BlackwellAttentionFix
```

---

# 此节点仅供 RTX 50xx 用户使用。其他所有用户可以删除它。  
这解决了与 LoRA 以及基于旧系统构建的节点之间的冲突。  
自定义节点位于本程序的文件夹文件中。请将其放置于此：  
```
📂 ComfyUI/
├── 📂 custom_nodes
│ ├── 📂 ComfyUI-BlackwellAttentionFix
