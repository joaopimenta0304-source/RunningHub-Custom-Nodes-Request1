"""
LC Text Overlay
---------------
Draw text on an image. alignment = left/center/right. x/y = position (y = top of block; default near bottom).
Curated fonts (real file paths + browser-friendly family names).
"""

import functools
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from nodes import PreviewImage

from .lc_image_helpers import tensor_to_np, np_to_tensor, preview_frames


def _coerce_overlay_text(text):
    """Accept str, list/tuple of str (Join/ShowText), or nested — always one string."""
    if text is None:
        return ""
    if isinstance(text, (list, tuple)):
        parts = []
        for x in text:
            if x is None:
                continue
            if isinstance(x, (list, tuple)):
                parts.append(_coerce_overlay_text(x))
            else:
                parts.append(str(x))
        return "\n".join(parts)
    return str(text)


def _preview(self, result_tensor, source_tensor=None):
    out = {"ui": {}, "result": (result_tensor,)}
    try:
        after = self.save_images(preview_frames(result_tensor), filename_prefix="lc_after")
        out["ui"]["lc_preview"] = after["ui"]["images"]
        if source_tensor is not None:
            before = self.save_images(preview_frames(source_tensor), filename_prefix="lc_before")
            out["ui"]["lc_before"] = before["ui"]["images"]
    except Exception:
        pass
    return out


# (display name, CSS family fallback, possible relative filenames)
_FONT_CANDIDATES = [
    ("Arial", "Arial, Helvetica, sans-serif", ["arial.ttf", "Arial.ttf", "arial.ttc", "DejaVuSans.ttf"]),
    ("Arial Bold", "Arial, Helvetica, sans-serif", ["arialbd.ttf", "Arial Bold.ttf", "Arial-Bold.ttf", "DejaVuSans-Bold.ttf"]),
    ("Arial Italic", "Arial, Helvetica, sans-serif", ["ariali.ttf", "Arial Italic.ttf", "DejaVuSans-Oblique.ttf"]),
    ("Times New Roman", "Times New Roman, Times, serif", ["times.ttf", "times.ttc", "Times New Roman.ttf", "DejaVuSerif.ttf", "LiberationSerif-Regular.ttf"]),
    ("Times New Roman Bold", "Times New Roman, Times, serif", ["timesbd.ttf", "Times New Roman Bold.ttf", "DejaVuSerif-Bold.ttf"]),
    ("Georgia", "Georgia, serif", ["georgia.ttf", "Georgia.ttf"]),
    ("Georgia Bold", "Georgia, serif", ["georgiab.ttf", "Georgia Bold.ttf"]),
    ("Verdana", "Verdana, Geneva, sans-serif", ["verdana.ttf", "Verdana.ttf", "DejaVuSans.ttf"]),
    ("Verdana Bold", "Verdana, Geneva, sans-serif", ["verdanab.ttf", "Verdana Bold.ttf"]),
    ("Tahoma", "Tahoma, sans-serif", ["tahoma.ttf", "Tahoma.ttf", "DejaVuSans.ttf"]),
    ("Trebuchet MS", "Trebuchet MS, sans-serif", ["trebuc.ttf", "Trebuchet MS.ttf"]),
    ("Comic Sans MS", "Comic Sans MS, cursive", ["comic.ttf", "Comic Sans MS.ttf", "comicbd.ttf"]),
    ("Impact", "Impact, Haettenschweiler, sans-serif", ["impact.ttf", "Impact.ttf"]),
    ("Courier New", "Courier New, Courier, monospace", ["cour.ttf", "courbd.ttf", "Courier New.ttf", "DejaVuSansMono.ttf"]),
    ("Consolas", "Consolas, monospace", ["consola.ttf", "Consolas.ttf", "DejaVuSansMono.ttf"]),
    ("Segoe UI", "Segoe UI, sans-serif", ["segoeui.ttf", "SegoeUI.ttf", "segoeuib.ttf"]),
    ("Segoe UI Bold", "Segoe UI, sans-serif", ["segoeuib.ttf", "Segoe UI Bold.ttf"]),
    ("Calibri", "Calibri, sans-serif", ["calibri.ttf", "Calibri.ttf", "calibril.ttf"]),
    ("Calibri Bold", "Calibri, sans-serif", ["calibrib.ttf", "Calibri Bold.ttf"]),
    ("DejaVu Sans", "DejaVu Sans, sans-serif", ["DejaVuSans.ttf"]),
    ("DejaVu Serif", "DejaVu Serif, serif", ["DejaVuSerif.ttf"]),
    ("DejaVu Sans Mono", "DejaVu Sans Mono, monospace", ["DejaVuSansMono.ttf"]),
    ("Liberation Sans", "Liberation Sans, Arial, sans-serif", ["LiberationSans-Regular.ttf"]),
    ("Liberation Serif", "Liberation Serif, Times, serif", ["LiberationSerif-Regular.ttf"]),
    # bundled with the pack (web/fonts), the same set LC Label uses
    ("Bebas Neue", '"Bebas Neue", sans-serif', ["BebasNeue-Regular.ttf"]),
    ("Oswald", "Oswald, sans-serif", ["Oswald-Variable.ttf"]),
    ("Permanent Marker", '"Permanent Marker", cursive', ["PermanentMarker-Regular.ttf"]),
    ("Pacifico", "Pacifico, cursive", ["Pacifico-Regular.ttf"]),
    ("Lobster", "Lobster, cursive", ["Lobster-Regular.ttf"]),
    ("Great Vibes", '"Great Vibes", cursive', ["GreatVibes-Regular.ttf"]),
    ("Abril Fatface", '"Abril Fatface", serif', ["AbrilFatface-Regular.ttf"]),
    ("Cinzel Decorative", '"Cinzel Decorative", serif', ["CinzelDecorative-Regular.ttf"]),
    ("UnifrakturMaguntia", "UnifrakturMaguntia, serif", ["UnifrakturMaguntia-Book.ttf"]),
    ("Monoton", "Monoton, sans-serif", ["Monoton-Regular.ttf"]),
    ("Bangers", "Bangers, sans-serif", ["Bangers-Regular.ttf"]),
    ("Creepster", "Creepster, sans-serif", ["Creepster-Regular.ttf"]),
    ("Rubik Glitch", '"Rubik Glitch", sans-serif', ["RubikGlitch-Regular.ttf"]),
    ("Press Start 2P", '"Press Start 2P", monospace', ["PressStart2P-Regular.ttf"]),
]

_FONT_DIRS = [
    Path(__file__).resolve().parent / "web" / "fonts",  # bundled fonts win over a same-named system copy
    Path("C:/Windows/Fonts"),
    Path("/usr/share/fonts"),
    Path("/usr/share/fonts/truetype"),
    Path("/usr/local/share/fonts"),
    Path.home() / ".fonts",
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
    Path.home() / "Library/Fonts",
]


def _resolve_fonts():
    """Build {display_name: {"path": str|None, "css": str}} for fonts that exist."""
    found = {}
    # index all font files once
    index = {}
    for d in _FONT_DIRS:
        if not d.exists():
            continue
        try:
            for p in d.rglob("*"):
                if p.suffix.lower() in (".ttf", ".otf", ".ttc"):
                    index.setdefault(p.name.lower(), p)
                    index.setdefault(p.stem.lower(), p)
        except Exception:
            pass

    for display, css, candidates in _FONT_CANDIDATES:
        path = None
        for name in candidates:
            hit = index.get(name.lower()) or index.get(Path(name).stem.lower())
            if hit is not None:
                path = str(hit)
                break
        # Always list curated fonts; path may be None → PIL default
        found[display] = {"path": path, "css": css}
    return found


_FONT_MAP = _resolve_fonts()
_FONT_NAMES = list(_FONT_MAP.keys())
MARGIN_PX = 6  # must match IMAGE_MARGIN_PX in web/lc_image_preview.js (text overlay)


@functools.lru_cache(maxsize=64)
def _truetype(path, size):
    """Font files are read once per (path, size); the fit search below asks for the same sizes every run."""
    return ImageFont.truetype(path, size)


def _text_bbox(draw, s, font):
    try:
        return draw.textbbox((0, 0), s or " ", font=font)
    except Exception:
        return (0, 0, len(s or " ") * 10, 12)


def _text_width(draw, s, font):
    l, t, r, b = _text_bbox(draw, s, font)
    return max(0, r - l)


def _wrap_line(draw, line, font, max_w):
    line = line.rstrip("\r")
    if not line:
        return [""]
    if _text_width(draw, line, font) <= max_w:
        return [line]
    words = line.split(" ")
    rows, cur = [], ""
    for w in words:
        trial = w if not cur else (cur + " " + w)
        if _text_width(draw, trial, font) <= max_w:
            cur = trial
        else:
            if cur:
                rows.append(cur)
            if _text_width(draw, w, font) > max_w:
                chunk = ""
                for ch in w:
                    t2 = chunk + ch
                    if _text_width(draw, t2, font) <= max_w:
                        chunk = t2
                    else:
                        if chunk:
                            rows.append(chunk)
                        chunk = ch
                cur = chunk
            else:
                cur = w
    if cur:
        rows.append(cur)
    return rows or [""]


MIN_FONT_PX = 8  # floor for the auto-shrink below -- smaller than this isn't legible anyway


def _layout(draw, paragraphs, font_fn, size, max_w):
    """Wrap + measure at one font size. Returns (font_obj, lines, metrics, gap, block_h, max_line_w)."""
    font_obj = font_fn(size)
    lines = []
    for para in paragraphs:
        lines.extend(_wrap_line(draw, para, font_obj, max_w))
    if not lines:
        lines = [""]
    metrics = []
    for ln in lines:
        l, t, r, b = _text_bbox(draw, ln, font_obj)
        metrics.append((l, t, r, b, max(1, b - t)))
    gap = max(2, int(size * 0.15))
    # Each line's own lh (= b - t) is already its true rendered height, top-bearing and descender both
    # included -- the total block is just those stacked with a gap between, no separate ascent term. (The
    # previous version only added an ascent correction when t was negative, but textbbox's t is usually
    # *positive* for plain text -- PIL's default anchor measures from the font's ascender line, which sits
    # above typical cap-height -- so the block quietly ran taller than predicted and could still spill past
    # the margin the fit search was aiming for.)
    block_h = sum(m[4] for m in metrics) + gap * (len(metrics) - 1)
    max_line_w = max((max(0, r - l) for (l, t, r, b, lh) in metrics), default=0)
    return font_obj, lines, metrics, gap, block_h, max_line_w


def _fit_text_to_box(draw, paragraphs, font_fn, requested_size, max_w, max_h, min_size=MIN_FONT_PX):
    """Largest font size <= requested_size whose wrapped block fits within max_w x max_h (the preview box,
    minus margin). Binary search over integer sizes -- ~6-8 layout passes regardless of how far it has to
    shrink, so this stays cheap even on a tiny image with a big requested size. Already fits at the
    requested size (the common case): one pass, unchanged output. Doesn't fit anywhere down to min_size:
    renders at min_size rather than failing -- still may clip a hair, but nowhere near as far as the
    unshrunk text would have.
    """
    requested_size = max(min_size, int(requested_size))

    def fits(res):
        return res[4] <= max_h and res[5] <= max_w

    at_requested = _layout(draw, paragraphs, font_fn, requested_size, max_w)
    if fits(at_requested):
        return at_requested

    lo, hi = min_size, requested_size
    best = _layout(draw, paragraphs, font_fn, min_size, max_w)
    while lo <= hi:
        mid = (lo + hi) // 2
        res = _layout(draw, paragraphs, font_fn, mid, max_w)
        if fits(res):
            best = res
            lo = mid + 1
        else:
            hi = mid - 1
    return best


class LCTextOverlay(PreviewImage):
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "text": ("STRING", {
                    "default": "Hello",
                    "multiline": True,
                    "tooltip": "Text to draw (wraps at edges with a small margin)",
                }),
                "font": (_FONT_NAMES, {
                    "default": _FONT_NAMES[0],
                    "tooltip": "Font family (curated list — changes apply on queue; live preview uses matching CSS name)",
                }),
                "font_size": ("INT", {
                    "default": 64, "min": 1, "max": 512, "step": 1,
                    "tooltip": "Font size in pixels",
                }),
                "color_r": ("INT", {
                    "default": 255, "min": 0, "max": 255, "step": 1,
                    "tooltip": "Red",
                }),
                "color_g": ("INT", {
                    "default": 255, "min": 0, "max": 255, "step": 1,
                    "tooltip": "Green",
                }),
                "color_b": ("INT", {
                    "default": 255, "min": 0, "max": 255, "step": 1,
                    "tooltip": "Blue",
                }),
                "x_percent": ("FLOAT", {
                    "default": 50.0, "min": 0.0, "max": 100.0, "step": 0.1,
                    "tooltip": "X position (% from left). Drag on preview or use the widget.",
                }),
                "y_percent": ("FLOAT", {
                    "default": 92.0, "min": 0.0, "max": 100.0, "step": 0.1,
                    "tooltip": "Y of the top of the text block (% from top). Default near bottom. Drag or use the widget.",
                }),
                "alignment": ([
                    # Current controls
                    "left", "center", "right",
                    # Legacy anchor values (old workflows) — mapped to left/center/right
                    "left-top", "center-top", "right-top",
                    "left-center", "center-center", "right-center",
                    "left-bottom", "center-bottom", "right-bottom",
                ], {
                    "default": "center",
                    "tooltip": "Horizontal alignment: left / center / right. Legacy *-top/center/bottom values still load and map to left/center/right.",
                }),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("image",)
    FUNCTION = "run"
    CATEGORY = "LC123/image"
    OUTPUT_NODE = True
    DESCRIPTION = (
        "Draw text on an image. Drag on the preview to place; font size/color/position update live. Multiline with edge margin."
    )

    def _font(self, name, size):
        info = _FONT_MAP.get(name) or {}
        path = info.get("path")
        try:
            if path:
                return _truetype(path, size)
        except Exception as e:
            print(f"[LCTextOverlay] font load failed '{name}' path={path}: {e}")
        try:
            return ImageFont.load_default(size=size)
        except TypeError:
            return ImageFont.load_default()

    def run(self, image, text, font, font_size, color_r, color_g, color_b,
            x_percent, y_percent, alignment="center", anchor=None, **kwargs):
        text = _coerce_overlay_text(text)
        if not text:
            return _preview(self, image, image)

        color = (int(color_r), int(color_g), int(color_b), 255)
        # Prefer alignment; accept legacy "anchor" or "left-top" style values
        raw = alignment if alignment is not None else anchor
        if raw is None:
            raw = kwargs.get("anchor", "center")
        raw = str(raw or "center").lower().strip()
        ah = raw.split("-")[0] if "-" in raw else raw
        if ah not in ("left", "center", "right"):
            ah = "center"

        paragraphs = str(text).split("\n")
        arrays = tensor_to_np(image)
        out = []
        layouts = {}  # the layout only depends on the frame size, so a batch lays out once
        for img in arrays:
            pil = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).convert("RGBA")
            draw = ImageDraw.Draw(pil)
            w, h = pil.size
            max_w = max(8, w - 2 * MARGIN_PX)
            max_h = max(8, h - 2 * MARGIN_PX)

            # Text that would overflow the image at the requested size is shrunk (never enlarged) to the
            # largest size that fits the padded box -- a giant font_size on a small image no longer runs
            # the letters off the edge, it just renders smaller. Already fits: unchanged, one layout pass.
            if (w, h) not in layouts:
                layouts[(w, h)] = _fit_text_to_box(
                    draw, paragraphs, lambda sz: self._font(font, sz), int(font_size), max_w, max_h
                )
            font_obj, lines, metrics, gap, block_h, _max_line_w = layouts[(w, h)]

            cx = int(w * (float(x_percent) / 100.0))
            # y_percent = top of text block (no vertical anchor)
            top_y = int(h * (float(y_percent) / 100.0))
            top_y = int(max(MARGIN_PX, min(h - MARGIN_PX - block_h, top_y)))
            if block_h > h - 2 * MARGIN_PX:
                top_y = MARGIN_PX

            # top_edge tracks where THIS line's glyph bbox top should land; draw.text's own y places the
            # bbox top at draw_y + t, so draw_y = top_edge - t gets it there regardless of the sign of t
            # (fixes the same top-bearing gap that block_h accounts for above).
            top_edge = top_y
            for (ln, (l, t, r, b, lh)) in zip(lines, metrics):
                tw = max(0, r - l)
                if ah == "left":
                    x = cx - l
                elif ah == "right":
                    x = cx - tw - l
                else:
                    x = cx - tw // 2 - l
                x = int(max(MARGIN_PX - l, min(w - MARGIN_PX - tw - l, x)))
                draw_y = top_edge - t
                draw.text((x, draw_y), ln, font=font_obj, fill=color)
                top_edge = top_edge + lh + gap

            rgb = np.array(pil.convert("RGB")).astype(np.float32) / 255.0
            out.append(rgb)

        result = _preview(self, np_to_tensor(out), image)
        # So the on-node preview can show Join/etc. text after the first run
        try:
            result.setdefault("ui", {})
            result["ui"]["lc_overlay_text"] = [text]
        except Exception:
            pass
        return result


NODE_CLASS_MAPPINGS = {
    "LCTextOverlay": LCTextOverlay,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "LCTextOverlay": "LC Text Overlay",
}
