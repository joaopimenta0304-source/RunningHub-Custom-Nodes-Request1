const { app } = window.comfyAPI.app;

const NODE_NAMES = new Set(["AnimaRegionalCanvasInline", "Krea2RegionalCanvasInline", "AnimaRegionalCanvas", "AnimaRegionalInpaintCanvas"]);
const COLORS = [
  ["RED", "#ff0000", "red_prompt"],
  ["GREEN", "#00ff00", "green_prompt"],
  ["BLUE", "#0000ff", "blue_prompt"],
];
const HISTORY_LIMIT = 5;
const MAX_STROKE_POINTS = 96;
const STANDARD_NODE_SIZE = [1430, 1270];
const ARC_BACKUP_PREFIX = "anima_regional_canvas:";
const CANVAS_SIZE_VERSION = 1;

function findWidget(node, name) {
  return node.widgets?.find((w) => w.name === name);
}

function hideWidget(widget) {
  if (!widget) return;
  widget.hidden = true;
  widget.computeSize = () => [0, -4];
  widget.serialize = true;
}

// The old key was type:id only, so another workflow's node with the same id could hand back the wrong mask.
// The key now includes the workflow's id (saved in the workflow file) when there is one.
function legacyBackupKey(node) {
  return `${ARC_BACKUP_PREFIX}${node.type}:${node.id}`;
}

function canvasBackupKey(node) {
  const g = node.graph ?? app.graph;
  const wf = (g?.rootGraph ?? g)?.id;
  return wf ? `${ARC_BACKUP_PREFIX}${wf}:${node.type}:${node.id}` : legacyBackupKey(node);
}

// This workflow's own backup rescues paint that was never saved (safe: the key is specific to this workflow).
// The old type:id key is shared by every workflow, so it is only used when the node has no saved canvas value at all.
function readCanvasBackup(node, allowLegacy) {
  try {
    const own = canvasBackupKey(node);
    const legacy = legacyBackupKey(node);
    if (own !== legacy) return localStorage.getItem(own) || (allowLegacy ? localStorage.getItem(legacy) : "") || "";
    return allowLegacy ? localStorage.getItem(legacy) || "" : "";
  } catch (_) {
    return "";
  }
}

function writeCanvasBackup(node, payload) {
  try {
    localStorage.setItem(canvasBackupKey(node), payload || "");
    // a cleared canvas also clears an old-key backup, so it cannot come back through the fallback above
    if (!payload && canvasBackupKey(node) !== legacyBackupKey(node) && localStorage.getItem(legacyBackupKey(node))) {
      localStorage.setItem(legacyBackupKey(node), "");
    }
  } catch (_) {}
}

function stop(ev) {
  ev.stopPropagation();
}

function makeButton(text, title) {
  const b = document.createElement("button");
  b.textContent = text;
  b.title = title || "";
  b.className = "arc-btn";
  b.addEventListener("pointerdown", stop);
  b.addEventListener("mousedown", stop);
  return b;
}

function inputViewUrl(value) {
  if (!value) return null;
  let filename = String(value);
  let subfolder = "";
  const lastSlash = filename.lastIndexOf("/");
  if (lastSlash >= 0) {
    subfolder = filename.slice(0, lastSlash);
    filename = filename.slice(lastSlash + 1);
  }
  const params = new URLSearchParams({ filename, type: "input", subfolder });
  params.set("no-cache", String(Date.now()));
  return `/view?${params.toString()}`;
}

function ensureStyle() {
  if (document.getElementById("arc-style")) return;
  const style = document.createElement("style");
  style.id = "arc-style";
  style.textContent = `
    .arc-wrap{display:flex;flex-direction:column;gap:6px;min-height:520px;overflow:hidden;color:#d7d7d7;font:12px sans-serif}
    .arc-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .arc-main{display:grid;grid-template-columns:minmax(260px,1fr) 470px;gap:8px;min-height:0;flex:1}
    .arc-canvasbox{background:#181818;border:1px solid #444;border-radius:6px;display:flex;align-items:center;justify-content:center;min-height:260px;overflow:hidden;position:relative}
    .arc-canvas{background:#fff;cursor:none;touch-action:none;max-width:100%;max-height:100%}
    .arc-canvas-layer{position:relative;display:inline-block;line-height:0}
    .arc-brush-preview{position:absolute;border:1px solid rgba(255,255,255,.95);box-shadow:0 0 0 1px rgba(0,0,0,.75),0 0 6px rgba(0,0,0,.45);border-radius:50%;pointer-events:none;display:none;box-sizing:border-box;mix-blend-mode:difference;transform:translate(-50%,-50%)}
    .arc-prompts{display:flex;flex-direction:column;gap:5px;min-width:0;background:#242424;padding:6px;border-radius:5px}
    .arc-row{display:grid;grid-template-columns:58px 1fr;gap:6px;align-items:stretch}
    .arc-label{display:flex;align-items:center;justify-content:center;font-weight:700;border-radius:2px;color:#fff;min-height:86px;text-align:center}
    .arc-label.base{background:#4b4b4b}.arc-label.neg{background:#2b2b2b;border:1px solid #555}
    .arc-text{display:block;width:100%;height:86px;background:#1b1b1b;color:#eee;border:1px solid #333;border-radius:3px;resize:vertical;min-height:86px;padding:5px 7px;font:12px monospace;box-sizing:border-box}
    .arc-sw{width:22px;height:22px;border:2px solid #777;border-radius:4px;cursor:pointer}
    .arc-sw.active{border-color:#e6e6e6;box-shadow:inset 0 0 0 2px #111}
    .arc-btn{background:#303030;color:#ddd;border:1px solid #555;border-radius:4px;padding:2px 8px;cursor:pointer}
    .arc-btn:hover{border-color:#999;color:#fff}
    .arc-range{width:110px}
    .arc-small{color:#aaa}
    .arc-info{color:#b8c7d9;background:#202833;border:1px solid #45515f;border-radius:4px;padding:2px 7px;font-size:11px}
    .arc-settings{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
    .arc-num{width:64px;background:#202020;color:#eee;border:1px solid #555;border-radius:4px;padding:2px 6px;text-align:right;box-sizing:border-box}
    .arc-px{margin-left:-5px;color:#aaa}
    .arc-switch{width:16px;height:16px;accent-color:#62d45f}
  `;
  document.head.appendChild(style);
}

app.registerExtension({
  name: "anima.regional.canvas",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (!NODE_NAMES.has(nodeData.name)) return;

    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      original?.apply(this, arguments);
      ensureStyle();

      const node = this;
      node.properties = node.properties || {};
      const markDirty = () => app.graph?.setDirtyCanvas?.(true, true);
      function removeLegacyInputs() {
        let index = node.inputs?.findIndex((input) => input.name === "base_prompt_in") ?? -1;
        while (index >= 0) {
          node.removeInput(index);
          index = node.inputs?.findIndex((input) => input.name === "base_prompt_in") ?? -1;
        }
      }
      removeLegacyInputs();
      const canvasData = findWidget(node, "canvas_data");
      const widthW = findWidget(node, "width");
      const heightW = findWidget(node, "height");
      const brushW = findWidget(node, "brush_size");
      const regionStrengthW = findWidget(node, "region_strength");
      const regionalEnabledW = findWidget(node, "regional_enabled");
      const promptNames = ["quality_prompt", "scene_prompt", ...COLORS.map((c) => c[2]), "negative_prompt"];
      node.properties.animaPrompts = node.properties.animaPrompts || {};
      const promptWidgets = promptNames.map((name) => findWidget(node, name));
      const promptTextareas = new Map();

      function promptValue(name) {
        const saved = node.properties.animaPrompts?.[name];
        if (typeof saved === "string") return saved;
        return findWidget(node, name)?.value ?? "";
      }
      function setPromptValue(name, value) {
        const text = String(value ?? "");
        const widget = findWidget(node, name);
        if (widget) widget.value = text;
        node.properties.animaPrompts[name] = text;
      }
      function savePrompts() {
        for (const name of promptNames) {
          const textarea = promptTextareas.get(name);
          setPromptValue(name, textarea?.value ?? promptValue(name));
        }
      }
      function serializedWidgets() {
        return (node.widgets || []).filter((widget) => widget.serialize !== false);
      }
      function setSerializedWidgetValue(workflowNode, name, value) {
        if (!workflowNode) return;
        const index = serializedWidgets().findIndex((widget) => widget.name === name);
        if (index < 0) return;
        workflowNode.widgets_values = workflowNode.widgets_values || [];
        workflowNode.widgets_values[index] = value;
      }
      // is the canvas_data value absent from a saved node (not just an empty string)? Same slot mapping as below.
      function serializedCanvasMissing(info) {
        const named = info?.widgets_values_named;
        if (named && typeof named === "object" && Object.prototype.hasOwnProperty.call(named, "canvas_data")) {
          return named.canvas_data == null;
        }
        const index = serializedWidgets().findIndex((widget) => widget.name === "canvas_data");
        if (index < 0) return true;
        const values = Array.isArray(info?.widgets_values) ? info.widgets_values : [];
        return values[index] == null;
      }
      function writeSerializedValues(workflowNode) {
        savePrompts();
        setSerializedWidgetValue(workflowNode, "width", Number(widthW?.value ?? 1024));
        setSerializedWidgetValue(workflowNode, "height", Number(heightW?.value ?? 1024));
        for (const name of promptNames) {
          setSerializedWidgetValue(workflowNode, name, promptValue(name));
        }
        setSerializedWidgetValue(workflowNode, "brush_size", Number(brushW?.value ?? brush?.value ?? 92));
        setSerializedWidgetValue(workflowNode, "regional_enabled", regionalEnabledW?.value ?? regionalToggle?.checked ?? true);
        setSerializedWidgetValue(workflowNode, "region_strength", Number(regionStrengthW?.value ?? strength?.value ?? 1));
        if (canvasData) {
          setSerializedWidgetValue(workflowNode, "canvas_data", canvasData.value ?? "");
        }
      }
      function syncPromptTextareas() {
        for (const name of promptNames) {
          const value = promptValue(name);
          const textarea = promptTextareas.get(name);
          if (textarea && textarea.value !== value) textarea.value = value;
          setPromptValue(name, value);
        }
      }

      hideWidget(canvasData);
      hideWidget(widthW);
      hideWidget(heightW);
      hideWidget(brushW);
      hideWidget(regionStrengthW);
      hideWidget(regionalEnabledW);
      for (const w of promptWidgets) hideWidget(w);

      const wrap = document.createElement("div");
      wrap.className = "arc-wrap";

      const regionalToggle = { checked: regionalEnabledW?.value !== false };
      const strength = { value: String(regionStrengthW?.value ?? 0.95) };
      if (regionalEnabledW) regionalEnabledW.value = regionalToggle.checked;
      if (regionStrengthW) regionStrengthW.value = Number(strength.value) || 0.95;

      const toolbar = document.createElement("div");
      toolbar.className = "arc-toolbar";
      const mode = document.createElement("span");
      mode.className = "arc-small";
      mode.textContent = "resolution";
      toolbar.appendChild(mode);
      const sizeLabel = document.createElement("span");
      sizeLabel.className = "arc-info";
      sizeLabel.title = "Resolution from width/height connections";
      toolbar.appendChild(sizeLabel);

      let activeColor = COLORS[0][1];
      for (const [label, hex] of COLORS) {
        const sw = document.createElement("button");
        sw.className = "arc-sw" + (hex === activeColor ? " active" : "");
        sw.style.background = hex;
        sw.title = label;
        sw.addEventListener("click", () => {
          activeColor = hex;
          toolbar.querySelectorAll(".arc-sw").forEach((x) => x.classList.remove("active"));
          sw.classList.add("active");
        });
        toolbar.appendChild(sw);
      }

      const white = document.createElement("button");
      white.className = "arc-sw";
      white.style.background = "#ffffff";
      white.title = "ERASE / WHITE";
      white.addEventListener("click", () => {
        activeColor = "#ffffff";
        toolbar.querySelectorAll(".arc-sw").forEach((x) => x.classList.remove("active"));
        white.classList.add("active");
      });
      toolbar.appendChild(white);

      const brushLabel = document.createElement("span");
      brushLabel.className = "arc-small";
      brushLabel.textContent = "Brush";
      const brush = document.createElement("input");
      brush.type = "range";
      brush.min = "1";
      brush.max = "512";
      brush.step = "1";
      brush.className = "arc-range";
      brush.value = brushW?.value ?? 92;
      const brushNum = document.createElement("input");
      brushNum.type = "number";
      brushNum.min = "1";
      brushNum.max = "512";
      brushNum.step = "1";
      brushNum.value = brush.value;
      brushNum.className = "arc-num";
      const brushPx = document.createElement("span");
      brushPx.className = "arc-px";
      brushPx.textContent = "px";
      const syncBrush = (mark = true) => {
        const val = Math.max(1, Math.min(512, Math.round(Number(brush.value) || 92)));
        brush.value = String(val);
        brushNum.value = String(val);
        if (brushW) brushW.value = val;
        if (mark) markDirty();
      };
      const setBrush = (value) => {
        brush.value = String(value);
        syncBrush();
      };
      brush.addEventListener("input", () => setBrush(brush.value));
      brushNum.addEventListener("input", () => setBrush(brushNum.value));
      brush.addEventListener("pointerdown", stop);
      brushNum.addEventListener("pointerdown", stop);
      syncBrush(false);
      toolbar.appendChild(brushLabel);
      toolbar.appendChild(brushNum);
      toolbar.appendChild(brushPx);
      toolbar.appendChild(brush);

      const opacity = document.createElement("input");
      opacity.type = "range";
      opacity.min = "0.1";
      opacity.max = "1";
      opacity.step = "0.01";
      opacity.value = node.properties.brushOpacity ?? "1";
      opacity.title = "Global mask strength — applies to all painted regions; updates on change";
      opacity.className = "arc-range";
      const opacityNum = document.createElement("input");
      opacityNum.type = "number";
      opacityNum.min = "0.1";
      opacityNum.max = "1";
      opacityNum.step = "0.01";
      opacityNum.value = opacity.value;
      opacityNum.className = "arc-num";
      const opacityLabel = document.createElement("span");
      opacityLabel.className = "arc-small";
      opacityLabel.textContent = "Opacity";
      opacityLabel.title = "Global mask strength. Changing this rescales the entire painted mask.";
      const syncOpacity = (v, rescaleMask = true) => {
        const val = Math.max(0.1, Math.min(1, Number(v) || 1));
        opacity.value = String(val);
        opacityNum.value = String(val);
        node.properties.brushOpacity = val;
        if (rescaleMask) {
          applyGlobalOpacityToMask(val);
          redrawDisplay();
          scheduleSaveData();
        }
      };
      opacity.addEventListener("input", () => syncOpacity(opacity.value, true));
      opacityNum.addEventListener("input", () => syncOpacity(opacityNum.value, true));
      opacity.addEventListener("pointerdown", stop);
      opacityNum.addEventListener("pointerdown", stop);
      toolbar.append(opacityLabel, opacity, opacityNum);


      const undo = makeButton("Undo", "Undo");
      const clear = makeButton("Clear Canvas", "Clear painted regions on the canvas");
      const resetBrush = makeButton("Reset 🖌️", "Reset brush settings");
      const applyBtn = makeButton("Apply", "Save canvas and continue (mxStop-style Continue)");
      applyBtn.style.background = "#1b5e20";
      applyBtn.style.color = "#e8f5e9";
      applyBtn.style.border = "2px solid #00e676";
      applyBtn.style.boxShadow = "0 0 0 2px #1b5e20, 0 0 12px rgba(0,230,118,0.45)";
      applyBtn.style.fontWeight = "700";
      applyBtn.style.fontSize = "14px";
      applyBtn.style.padding = "8px 28px";
      applyBtn.style.marginLeft = "8px";
      applyBtn.style.minWidth = "120px";
      applyBtn.style.minHeight = "36px";
      const canvasWNum = null;
      const canvasHNum = null;
      resetBrush.addEventListener("click", () => {
        brush.value = "92";
        syncBrush();
        syncOpacity(1);
      });
      toolbar.appendChild(undo);
      toolbar.appendChild(clear);
      toolbar.appendChild(resetBrush);
      toolbar.appendChild(applyBtn);
      wrap.appendChild(toolbar);

      const main = document.createElement("div");
      main.className = "arc-main";
      const canvasBox = document.createElement("div");
      canvasBox.className = "arc-canvasbox";
      const canvasLayer = document.createElement("div");
      canvasLayer.className = "arc-canvas-layer";
      const canvas = document.createElement("canvas");
      canvas.className = "arc-canvas";
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      const maskCanvas = document.createElement("canvas");
      const maskCtx = maskCanvas.getContext("2d", { willReadFrequently: true });
      const brushPreview = document.createElement("div");
      brushPreview.className = "arc-brush-preview";
      canvasLayer.appendChild(canvas);
      canvasLayer.appendChild(brushPreview);
      canvasBox.appendChild(canvasLayer);
      function timestamp() {
        const d = new Date();
        const pad = (n) => String(n).padStart(2, "0");
        return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      }

      const prompts = document.createElement("div");
      prompts.className = "arc-prompts";
      const promptRows = [
        ["QUALITY", "#555555", "quality_prompt", "base", "quality tags, style tags"],
        ["SCENE", "#3a3a3a", "scene_prompt", "base", "2girls, character names, cafe, background, situation"],
        ...COLORS.map(([label, hex, name]) => [label, hex, name, "", `${label.toLowerCase()} region prompt`]),
        ["NEGATIVE", "#222222", "negative_prompt", "neg", "negative prompt"],
      ];
      for (const [label, hex, widgetName, cls, placeholder] of promptRows) {
        const row = document.createElement("div");
        row.className = "arc-row";
        const l = document.createElement("div");
        l.className = `arc-label ${cls}`;
        l.style.background = hex;
        l.title = placeholder;
        l.textContent = label;
        const t = document.createElement("textarea");
        t.classList.add("arc-text");
        t.name = widgetName;
        t.placeholder = placeholder;
        t.title = placeholder;
        t.id = t.id || `arc-${node.id ?? "new"}-${widgetName}`;
        t.dataset.arcPrompt = "true";
        t.dataset.widgetName = widgetName;
        t.dataset.comfyWidgetName = widgetName;
        t.dataset.comfyNode = node.comfyClass || "";
        t.autocomplete = "off";
        t.spellcheck = false;
        t.value = promptValue(widgetName);
        setPromptValue(widgetName, t.value);
        promptTextareas.set(widgetName, t);
        const commitPrompt = () => {
          setPromptValue(widgetName, t.value);
          markDirty();
        };
        t.addEventListener("input", commitPrompt);
        t.addEventListener("change", commitPrompt);
        t.addEventListener("keyup", commitPrompt);
        t.addEventListener("blur", commitPrompt);
        t.addEventListener("pointerdown", stop);
        t.addEventListener("mousedown", stop);
        row.append(l, t);
        prompts.appendChild(row);
      }

      main.append(canvasBox, prompts);
      wrap.appendChild(main);

      const history = [];
      let saveTimer = null;
      let resizeTimer = null;
      let lastWidth = null;
      let lastHeight = null;
      let lastInputImageKey = "";
      let backgroundImage = null;
      let lastArcSize = null;
      let lastServerHadImage = null;
      let canvasEdited = false;
      let statusLabel = document.createElement("div");
      statusLabel.className = "arc-status";
      statusLabel.style.cssText = "font-size:11px;color:#9e9e9e;padding:2px 6px;";
      statusLabel.textContent = "Idle — queue a prompt to load the image, then click Apply";
      wrap.appendChild(statusLabel);
      let hasCanvasContent = false;
      let isRestoringCanvas = false;
      let lastDisplayStyle = { width: "", height: "" };
      // saveData re-encodes the mask (pixel scan + PNG + JSON) only after it changed; every mask write sets this
      let maskDirty = true;
      let savedPayload = "";
      let savedPainted = false;
      let lastBackup = { key: null, payload: null };
      function setSizeLabel(text) {
        if (sizeLabel && sizeLabel.textContent !== text) sizeLabel.textContent = text;
      }
      let canvasResizeObserver = null;
      function visibleCanvasBox() {
        return canvasBox.isConnected && canvasBox.clientWidth > 16 && canvasBox.clientHeight > 16;
      }
      function safeDimension(value, fallback) {
        const n = Math.round(Number(value));
        const base = Number.isFinite(n) && n >= 16 ? n : Math.round(Number(fallback) || 1024);
        return Math.min(16384, Math.max(16, Math.floor(base / 8) * 8));
      }
      function markCanvasSizeInitialized() {
        node.properties.arcCanvasSizeVersion = CANVAS_SIZE_VERSION;
      }
      function canvasPayloadDimensions(payloadText) {
        if (!payloadText) return null;
        try {
          const payload = JSON.parse(payloadText);
          const width = Math.round(Number(payload.width));
          const height = Math.round(Number(payload.height));
          if (Number.isFinite(width) && Number.isFinite(height)) return { width, height };
        } catch (_) {}
        return null;
      }
      function dims() {
        return {
          w: safeDimension(widthW?.value, canvas.width || lastWidth || 1024),
          h: safeDimension(heightW?.value, canvas.height || lastHeight || 1024),
        };
      }
      function formatResolution(w, h) {
        return `${w} x ${h}`;
      }
      function syncSizeWidgetsToCanvas() {
        if (widthW && canvas.width) widthW.value = canvas.width;
        if (heightW && canvas.height) heightW.value = canvas.height;
        if (sizeLabel && canvas.width && canvas.height) setSizeLabel(formatResolution(canvas.width, canvas.height));
      }
      function syncCanvasSize(keep = false, force = false) {
        const { w, h } = dims();
        if (!force && w === lastWidth && h === lastHeight && canvas.width === w && canvas.height === h) return;
        resizeCanvasPreserve(w, h, keep);
      }
      function scheduleResizePreserve(force = false) {
        if (resizeTimer) clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          resizeTimer = null;
          syncCanvasSize(true, force);
        }, 120);
      }
      function saveData(options = {}) {
        if (saveTimer) {
          clearTimeout(saveTimer);
          saveTimer = null;
        }
        // ComfyUI serializes after most clicks: reuse the last encoding while the mask is unchanged
        if (maskDirty || !savedPayload) {
          savedPainted = maskHasPaint();
          savedPayload = JSON.stringify({
            version: 2,
            width: maskCanvas.width,
            height: maskCanvas.height,
            data_url: maskCanvas.toDataURL("image/png"),
          });
          maskDirty = false;
        }
        const painted = savedPainted;
        markCanvasSizeInitialized();
        const payload = savedPayload;
        if (canvasData) canvasData.value = payload;
        node.properties.arcCanvasData = payload;
        if (options.clearBackup) {
          writeCanvasBackup(node, "");
          lastBackup = { key: canvasBackupKey(node), payload: "" };
        } else if (painted || canvasEdited || hasCanvasContent || options.forceBackup) {
          // the same payload already stored under the same key is not written again
          const key = canvasBackupKey(node);
          if (lastBackup.key !== key || lastBackup.payload !== payload) {
            writeCanvasBackup(node, payload);
            lastBackup = { key, payload };
          }
        }
        hasCanvasContent = painted || canvasEdited || hasCanvasContent;
        markDirty();
      }
      function scheduleSaveData() {
        if (saveTimer) return;
        saveTimer = setTimeout(saveData, 250);
      }
      function pushHistory() {
        // Mask-only history (display is reconstructed) to limit RAM at high res
        try {
          history.push({
            mask: maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height),
          });
        } catch (_) {}
        while (history.length > HISTORY_LIMIT) history.shift();
      }
      function cloneCanvas(src) {
        if (!src?.width || !src?.height) return null;
        const clone = document.createElement("canvas");
        clone.width = src.width;
        clone.height = src.height;
        clone.getContext("2d").drawImage(src, 0, 0);
        return clone;
      }
      function resizeCanvasPreserve(w, h, keep = true) {
        w = safeDimension(w, canvas.width || lastWidth || 1024);
        h = safeDimension(h, canvas.height || lastHeight || 1024);
        const oldMask = keep ? cloneCanvas(maskCanvas) : null;
        lastWidth = w;
        lastHeight = h;
        if (widthW) widthW.value = w;
        if (heightW) heightW.value = h;
        canvas.width = w;
        canvas.height = h;
        maskDirty = true;
        maskCanvas.width = w;
        maskCanvas.height = h;
        ctx.imageSmoothingEnabled = false;
        maskCtx.imageSmoothingEnabled = false;
        maskCtx.fillStyle = "#ffffff";
        maskCtx.fillRect(0, 0, w, h);
        if (oldMask && oldMask.width && oldMask.height) maskCtx.drawImage(oldMask, 0, 0, w, h);
        canvasEdited = keep ? maskHasPaint() : false;
        hasCanvasContent = hasCanvasContent || canvasEdited;
        redrawDisplay();
        fitCanvas();
        saveData();
      }
      function resizeFromToolbar() {}
      function resetCanvas(keep = false) {
        const { w, h } = dims();
        resizeCanvasPreserve(w, h, keep);
      }
      function fitCanvas() {
        if (!visibleCanvasBox()) return;
        const maxW = Math.max(1, canvasBox.clientWidth - 8);
        const maxH = Math.max(1, canvasBox.clientHeight - 8);
        const scale = Math.min(maxW / canvas.width, maxH / canvas.height);
        const displayW = Math.max(1, Math.floor(canvas.width * scale));
        const displayH = Math.max(1, Math.floor(canvas.height * scale));
        lastDisplayStyle = { width: `${displayW}px`, height: `${displayH}px` };
        canvas.style.width = `${displayW}px`;
        canvas.style.height = `${displayH}px`;
        canvasLayer.style.width = `${displayW}px`;
        canvasLayer.style.height = `${displayH}px`;
        syncSizeWidgetsToCanvas();
      }
      function maskHasPaint() {
        try {
          const data = maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height).data;
          for (let i = 0; i < data.length; i += 4) {
            if (data[i] < 250 || data[i + 1] < 250 || data[i + 2] < 250) return true;
          }
        } catch (_) {}
        return false;
      }

      function applySizeFromValues(w, h, force = false) {
        w = safeDimension(w, canvas.width || 1024);
        h = safeDimension(h, canvas.height || 1024);
        if (!force && w === lastWidth && h === lastHeight && canvas.width === w && canvas.height === h) {
          setSizeLabel(formatResolution(w, h));
          return false;
        }
        if (widthW) widthW.value = w;
        if (heightW) heightW.value = h;
        resizeCanvasPreserve(w, h, true);
        setSizeLabel(formatResolution(w, h));
        return true;
      }
      function getLinkedOrigin(name) {
        const input = node.inputs?.find((slot) => slot.name === name);
        if (!input || input.link == null || !node.graph?.links) return null;
        const link = node.graph.links[input.link];
        if (!link) return null;
        const originId = link.origin_id ?? link[1];
        const originSlot = link.origin_slot ?? link[2] ?? 0;
        if (originId == null) return null;
        const source = node.graph.getNodeById?.(originId);
        if (!source) return null;
        return { source, originId, originSlot };
      }
      function isNodeInactive(n) {
        if (!n) return true;
        const m = n.mode;
        return m === 2 || m === 4 || m === "Never" || m === "Bypass";
      }
      function isImageSignalActive() {
        const info = getLinkedOrigin("image");
        if (!info) return false;
        if (isNodeInactive(info.source)) return false;
        return true;
      }
      function unwrapOutputValue(val) {
        if (val == null) return null;
        if (Array.isArray(val)) return unwrapOutputValue(val[0]);
        if (typeof val === "object" && val !== null && "value" in val) return unwrapOutputValue(val.value);
        if (Number.isFinite(Number(val))) return Number(val);
        if (typeof val === "string") return val;
        return null;
      }
      function isGetSetNode(source) {
        const t = source?.type || source?.comfyClass || "";
        return /GetNode|SetNode/i.test(t);
      }
      function readNumericFromNode(source, originSlot) {
        if (!source) return null;
        const outName = source.outputs?.[originSlot]?.name;
        try {
          const outs = app.nodeOutputs?.[source.id] ?? app.nodeOutputs?.[String(source.id)];
          if (outs != null) {
            if (typeof outs === "object" && !Array.isArray(outs)) {
              if (outName && outs[outName] != null) {
                const n = unwrapOutputValue(outs[outName]);
                if (n != null && Number.isFinite(n)) return n;
              }
            } else if (Array.isArray(outs)) {
              const n = unwrapOutputValue(outs[originSlot]);
              if (n != null && Number.isFinite(n)) return n;
            }
          }
        } catch (_) {}
        if (isGetSetNode(source)) return null;
        if (outName && Array.isArray(source.widgets)) {
          const w = source.widgets.find((x) => x && x.name === outName);
          if (w != null && w.value != null && Number.isFinite(Number(w.value))) return Number(w.value);
        }
        if (Array.isArray(source.widgets)) {
          for (const name of ["value", "int", "number", "Number", "INT"]) {
            const w = source.widgets.find((x) => x && x.name === name);
            if (w != null && w.value != null && Number.isFinite(Number(w.value))) return Number(w.value);
          }
        }
        return null;
      }
      function resolveStringFromGetSet(source) {
        if (!source || !node.graph) return null;
        const channel = source.widgets_values?.[0] ?? source.widgets?.[0]?.value;
        if (typeof channel !== "string" || !channel) return null;
        const nodes = node.graph._nodes || node.graph.nodes || [];
        for (const n of nodes) {
          if (!n || n === source) continue;
          if (!/SetNode/i.test(n.type || n.comfyClass || "")) continue;
          const setName = n.widgets_values?.[0] ?? n.widgets?.[0]?.value;
          if (setName !== channel) continue;
          const sin = n.inputs?.find((s) => s.type === "STRING" || s.name === "STRING" || s.name === "value");
          if (!sin || sin.link == null) continue;
          const link = node.graph.links[sin.link];
          if (!link) continue;
          const oid = link.origin_id ?? link[1];
          const oslot = link.origin_slot ?? link[2] ?? 0;
          const origin = node.graph.getNodeById?.(oid);
          if (!origin) continue;
          try {
            const outs = app.nodeOutputs?.[origin.id] ?? app.nodeOutputs?.[String(origin.id)];
            if (outs != null) {
              const outName = origin.outputs?.[oslot]?.name;
              if (typeof outs === "object" && !Array.isArray(outs) && outName && outs[outName] != null) {
                const v = unwrapOutputValue(outs[outName]);
                if (typeof v === "string" && v.length) return v;
              }
            }
          } catch (_) {}
          if (Array.isArray(origin.widgets)) {
            let best = null;
            for (const w of origin.widgets) {
              if (w && typeof w.value === "string" && w.value.length) {
                if (!best || w.value.length > best.length) best = w.value;
              }
            }
            if (best) return best;
          }
        }
        return null;
      }
      function connectedInputValue(name) {
        const info = getLinkedOrigin(name);
        if (!info) return null;
        return readNumericFromNode(info.source, info.originSlot);
      }
      function connectedStringValue(name) {
        const info = getLinkedOrigin(name);
        if (!info) return null;
        const { source, originSlot } = info;
        try {
          const outs = app.nodeOutputs?.[source.id] ?? app.nodeOutputs?.[String(source.id)];
          if (outs != null) {
            const outName = source.outputs?.[originSlot]?.name;
            if (typeof outs === "object" && !Array.isArray(outs) && outName && outs[outName] != null) {
              const v = unwrapOutputValue(outs[outName]);
              if (typeof v === "string" && v.length) return v;
            }
          }
        } catch (_) {}
        if (isGetSetNode(source)) return resolveStringFromGetSet(source);
        if (Array.isArray(source.widgets)) {
          let best = null;
          for (const w of source.widgets) {
            if (w && typeof w.value === "string" && w.value.length) {
              if (!best || w.value.length > best.length) best = w.value;
            }
          }
          if (best) return best;
        }
        return null;
      }
      function syncConnectedPrompts() {
        const pairs = [
          ["quality_prompt", "quality_prompt_in"],
          ["scene_prompt", "scene_prompt_in"],
          ["negative_prompt", "negative_prompt_in"],
        ];
        for (const [widgetName, inputName] of pairs) {
          const linked = getLinkedOrigin(inputName);
          const textarea = promptTextareas.get(widgetName);
          if (!textarea) continue;
          if (linked) {
            const text = connectedStringValue(inputName);
            if (text != null && text.length && textarea.value !== text) {
              textarea.value = text;
              setPromptValue(widgetName, text);
              textarea.readOnly = true;
              textarea.style.opacity = "0.85";
            }
          } else if (textarea.readOnly) {
            textarea.readOnly = false;
            textarea.style.opacity = "";
          }
        }
      }
      function applyConnectedSize(force = false) {
        if (lastArcSize?.width && lastArcSize?.height) {
          return applySizeFromValues(lastArcSize.width, lastArcSize.height, force);
        }
        const wIn = connectedInputValue("width");
        const hIn = connectedInputValue("height");
        if (wIn == null && hIn == null) return false;
        return applySizeFromValues(wIn ?? canvas.width, hIn ?? canvas.height, force);
      }
      function clearBackgroundToWhite() {
        backgroundImage = null;
        lastInputImageKey = "";
        lastServerHadImage = false;
        redrawDisplay();
      }
      function setBackgroundFromB64(b64, key) {
        if (!b64) {
          clearBackgroundToWhite();
          return;
        }
        const dataUrl = b64.startsWith("data:") ? b64 : `data:image/png;base64,${b64}`;
        if (key && key === lastInputImageKey && backgroundImage) return;
        const img = new Image();
        img.onload = () => {
          backgroundImage = img;
          lastInputImageKey = key || lastInputImageKey || dataUrl.slice(0, 64);
          lastServerHadImage = true;
          redrawDisplay();
          fitCanvas();
          if (statusLabel) statusLabel.textContent = "Image loaded — paint regions, then click Apply";
        };
        img.src = dataUrl;
      }
      function connectedImageSource() {
        const info = getLinkedOrigin("image");
        if (!info) return null;
        if (isNodeInactive(info.source)) return null;
        const { source, originId } = info;
        const imageWidget = source.widgets?.find((widget) => widget.name === "image");
        const url = inputViewUrl(imageWidget?.value);
        if (url) return { url, key: `${originId}:${imageWidget.value}` };
        const src = source.imgs?.[0]?.src;
        return src ? { url: src, key: `${originId}:${src}` } : null;
      }
      function redrawDisplay() {
        const w = canvas.width, h = canvas.height;
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        if (backgroundImage?.complete && backgroundImage.naturalWidth) {
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(backgroundImage, 0, 0, w, h);
        }
        try {
          if (maskCanvas.width === w && maskCanvas.height === h) {
            const md = maskCtx.getImageData(0, 0, w, h).data;
            const displayData = ctx.getImageData(0, 0, w, h);
            const dd = displayData.data;
            for (let i = 0; i < md.length; i += 4) {
              if (md[i] < 250 || md[i + 1] < 250 || md[i + 2] < 250) {
                dd[i] = md[i]; dd[i + 1] = md[i + 1]; dd[i + 2] = md[i + 2]; dd[i + 3] = 255;
              }
            }
            ctx.putImageData(displayData, 0, 0);
          }
        } catch (_) {
          ctx.drawImage(maskCanvas, 0, 0, w, h);
        }
        ctx.imageSmoothingEnabled = false;
      }
      function loadConnectedImage(force = false) {
        if (!isImageSignalActive()) {
          if (backgroundImage || lastInputImageKey) {
            clearBackgroundToWhite();
            if (statusLabel) statusLabel.textContent = "No image signal — blank white canvas";
          }
          return;
        }
        if (lastServerHadImage === false) {
          if (backgroundImage) clearBackgroundToWhite();
          return;
        }
        const source = connectedImageSource();
        if (!source) return;
        if (!force && source.key === lastInputImageKey && backgroundImage) return;
        if (isRestoringCanvas || !visibleCanvasBox()) return;
        const img = new Image();
        img.onload = () => {
          backgroundImage = img;
          lastInputImageKey = source.key;
          lastServerHadImage = true;
          redrawDisplay();
          fitCanvas();
        };
        img.onerror = () => {};
        img.src = source.url;
      }
      async function doApplyAndContinue() {
        saveData();
        if (statusLabel) statusLabel.textContent = "Applying — continuing workflow…";
        const canvasVal = findWidget(node, "canvas_data")?.value ?? "";
        try {
          const res = await fetch("/anima/canvas/apply", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ node_id: String(node.id), canvas_data: canvasVal, ts: Date.now() }),
          });
          if (!res.ok) {
            const body = await res.text().catch(() => "");
            throw new Error(body || `Apply endpoint HTTP ${res.status}`);
          }
          let queueResult;
          if (typeof app.queuePrompt === "function") {
            queueResult = app.queuePrompt(0);
          } else if (app.ui?.queuePrompt) {
            queueResult = app.ui.queuePrompt(0);
          } else {
            document.getElementById("queue-button")?.click();
          }
          if (queueResult != null && typeof queueResult.then === "function") {
            await queueResult;
          }
          if (statusLabel) statusLabel.textContent = "Applied — queued";
        } catch (err) {
          console.error("IRC Apply failed", err);
          if (statusLabel) {
            statusLabel.textContent =
              "Apply failed: " + (err?.message || String(err) || "queue/validation error");
          }
        }
      }
      applyBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        doApplyAndContinue();
      });

      function eventPoint(ev) {
        const r = canvas.getBoundingClientRect();
        return {
          x: (ev.clientX - r.left) * (canvas.width / r.width),
          y: (ev.clientY - r.top) * (canvas.height / r.height),
        };
      }
      function updateBrushPreview(ev) {
        const r = canvas.getBoundingClientRect();
        const layerRect = canvasLayer.getBoundingClientRect();
        if (!r.width || !r.height) return;
        const graphScale = layerRect.width / Math.max(1, canvasLayer.offsetWidth || layerRect.width);
        const scale = (r.width / canvas.width) / Math.max(graphScale, 0.0001);
        const size = Math.max(1, (Number(brush.value) || 1) * scale);
        const x = (ev.clientX - layerRect.left) / Math.max(graphScale, 0.0001);
        const y = (ev.clientY - layerRect.top) / Math.max(graphScale, 0.0001);
        brushPreview.style.display = "block";
        brushPreview.style.width = `${size}px`;
        brushPreview.style.height = `${size}px`;
        brushPreview.style.left = `${x}px`;
        brushPreview.style.top = `${y}px`;
      }
      /**
       * Mask model:
       * - maskCanvas stores PURE region colors (full R/G/B or white eraser).
       * - Opacity is a global strength applied on export + display.
       * - Painting never stacks: pure color replaces pure color (source-over).
       * - Changing Opacity rescales every painted pixel for Apply/conditioning.
       */
      function currentStrength() {
        return Math.max(0.1, Math.min(1, Number(opacity.value) || 1));
      }
      function strengthColor(hex, strength) {
        const s = Math.max(0, Math.min(1, Number(strength) || 1));
        if (String(hex).toLowerCase() === "#ffffff") return "#ffffff";
        const h = String(hex).replace("#", "");
        if (h.length !== 6) return hex;
        const r = Math.round(parseInt(h.slice(0, 2), 16) * s);
        const g = Math.round(parseInt(h.slice(2, 4), 16) * s);
        const b = Math.round(parseInt(h.slice(4, 6), 16) * s);
        return `rgb(${r},${g},${b})`;
      }
      const PURE = {
        red: [255, 0, 0],
        green: [0, 255, 0],
        blue: [0, 0, 255],
      };
      function nearestPure(r, g, b) {
        if (r >= 250 && g >= 250 && b >= 250) return null; // white
        const candidates = [
          ["red", PURE.red],
          ["green", PURE.green],
          ["blue", PURE.blue],
        ];
        let best = null;
        let bestD = Infinity;
        for (const [name, rgb] of candidates) {
          const d =
            (r - rgb[0]) ** 2 + (g - rgb[1]) ** 2 + (b - rgb[2]) ** 2;
          if (d < bestD) {
            bestD = d;
            best = rgb;
          }
        }
        return best;
      }
      /** Rewrite mask pixels to pureColor * strength (global opacity). */
      function applyGlobalOpacityToMask(strength) {
        const s = Math.max(0.1, Math.min(1, Number(strength) || 1));
        try {
          const w = maskCanvas.width;
          const h = maskCanvas.height;
          if (!w || !h) return;
          const img = maskCtx.getImageData(0, 0, w, h);
          const d = img.data;
          for (let i = 0; i < d.length; i += 4) {
            const pure = nearestPure(d[i], d[i + 1], d[i + 2]);
            if (!pure) {
              d[i] = d[i + 1] = d[i + 2] = 255;
              d[i + 3] = 255;
              continue;
            }
            d[i] = Math.round(pure[0] * s);
            d[i + 1] = Math.round(pure[1] * s);
            d[i + 2] = Math.round(pure[2] * s);
            d[i + 3] = 255;
          }
          maskCtx.putImageData(img, 0, 0);
          maskDirty = true;
        } catch (_) {}
      }
      function strokePath(targetCtx, points, color, alpha = 1) {
        if (!points.length) return;
        targetCtx.save();
        targetCtx.strokeStyle = color;
        targetCtx.fillStyle = color;
        targetCtx.globalAlpha = alpha;
        targetCtx.lineWidth = Number(brush.value);
        targetCtx.lineCap = "round";
        targetCtx.lineJoin = "round";
        // Replace pixels — no additive stacking of the same stroke
        targetCtx.globalCompositeOperation = "source-over";
        targetCtx.beginPath();
        targetCtx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          targetCtx.lineTo(points[i].x, points[i].y);
        }
        targetCtx.stroke();
        targetCtx.beginPath();
        const to = points[points.length - 1];
        targetCtx.arc(to.x, to.y, Number(brush.value) / 2, 0, Math.PI * 2);
        targetCtx.fill();
        targetCtx.restore();
      }
      function drawSmooth(from, to) {
        const dx = to.x - from.x;
        const dy = to.y - from.y;
        const dist = Math.hypot(dx, dy);
        // Fixed smooth step (~18% of brush) — Step control removed
        const step = Math.max(1, Number(brush.value) * 0.18);
        const count = Math.max(1, Math.min(MAX_STROKE_POINTS, Math.ceil(dist / step)));
        const points = [from];
        for (let i = 1; i <= count; i++) {
          const t = i / count;
          points.push({ x: from.x + dx * t, y: from.y + dy * t });
        }
        const s = currentStrength();
        // Visible preview
        strokePath(ctx, points, activeColor, s);
        // Authoritative mask: pure region * global strength (no stacking above pure)
        strokePath(maskCtx, points, strengthColor(activeColor, s), 1);
        maskDirty = true;
      }

      let drawing = false;
      let lastPoint = null;
      let brushAdjust = null;
      canvas.addEventListener("pointerdown", (ev) => {
        updateBrushPreview(ev);
        const isWindowsBrushAdjust = ev.altKey && ev.button === 2;
        const isMacBrushAdjust = ev.ctrlKey && ev.altKey && ev.button === 0;
        if (isWindowsBrushAdjust || isMacBrushAdjust) {
          ev.preventDefault();
          ev.stopPropagation();
          canvas.setPointerCapture(ev.pointerId);
          brushAdjust = {
            pointerId: ev.pointerId,
            x: ev.clientX,
            y: ev.clientY,
            brush: Number(brush.value) || 92,
            opacity: Number(opacity.value) || 1,
          };
          return;
        }
        if (ev.button !== 0) return;
        ev.preventDefault();
        ev.stopPropagation();
        canvas.setPointerCapture(ev.pointerId);
        pushHistory();
        canvasEdited = true;
        drawing = true;
        lastPoint = eventPoint(ev);
        drawSmooth(lastPoint, lastPoint);
        scheduleSaveData();
      });
      canvas.addEventListener("pointermove", (ev) => {
        updateBrushPreview(ev);
        if (brushAdjust && ev.pointerId === brushAdjust.pointerId) {
          ev.preventDefault();
          ev.stopPropagation();
          const dx = ev.clientX - brushAdjust.x;
          const dy = ev.clientY - brushAdjust.y;
          setBrush(brushAdjust.brush + dx);
          syncOpacity(brushAdjust.opacity - dy / 200);
          return;
        }
        if (!drawing) return;
        ev.preventDefault();
        const p = eventPoint(ev);
        drawSmooth(lastPoint || p, p);
        lastPoint = p;
        scheduleSaveData();
      });
      const endPointer = (ev) => {
        if (brushAdjust && ev.pointerId === brushAdjust.pointerId) {
          brushAdjust = null;
          markDirty();
          return;
        }
        drawing = false;
        lastPoint = null;
        saveData();
      };
      canvas.addEventListener("pointerup", endPointer);
      canvas.addEventListener("pointercancel", endPointer);
      canvas.addEventListener("pointerenter", updateBrushPreview);
      canvas.addEventListener("pointerleave", () => { brushPreview.style.display = "none"; });
      canvas.addEventListener("contextmenu", (ev) => ev.preventDefault());

      undo.addEventListener("click", () => {
        const prev = history.pop();
        if (!prev) return;
        maskCtx.putImageData(prev.mask, 0, 0);
        maskDirty = true;
        canvasEdited = maskHasPaint();
        redrawDisplay();
        saveData();
      });
      clear.addEventListener("click", () => {
        pushHistory();
        canvasEdited = false;
        hasCanvasContent = false;
        maskCtx.fillStyle = "#ffffff";
        maskCtx.fillRect(0, 0, maskCanvas.width, maskCanvas.height);
        maskDirty = true;
        redrawDisplay();
        saveData({ clearBackup: true });
      });

      function restoreCanvasFromText(payloadText) {
        if (!payloadText) return false;
        try {
          const payload = JSON.parse(payloadText);
          if (!payload?.data_url) return false;
          const img = new Image();
          img.onload = () => {
            isRestoringCanvas = true;
            try {
              const fallback = dims();
              const w = safeDimension(payload.width || img.naturalWidth || img.width, fallback.w);
              const h = safeDimension(payload.height || img.naturalHeight || img.height, fallback.h);
              if (widthW) widthW.value = w;
              if (heightW) heightW.value = h;
              lastWidth = w;
              lastHeight = h;
              canvas.width = w; canvas.height = h;
              maskDirty = true;
              maskCanvas.width = w; maskCanvas.height = h;
              ctx.imageSmoothingEnabled = false;
              maskCtx.imageSmoothingEnabled = false;
              ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, w, h);
              maskCtx.fillStyle = "#ffffff"; maskCtx.fillRect(0, 0, w, h);
              ctx.drawImage(img, 0, 0, w, h);
              maskCtx.drawImage(img, 0, 0, w, h);
              canvasEdited = maskHasPaint();
              hasCanvasContent = canvasEdited;
              fitCanvas();
              saveData({ forceBackup: canvasEdited });
            } finally {
              isRestoringCanvas = false;
            }
          };
          img.src = payload.data_url;
          return true;
        } catch (_) {
          return false;
        }
      }

      // no saved canvas: this workflow's own backup brings back unsaved paint; the shared old-style backup only
      // when the node carries no canvas value at all
      const existing = canvasData?.value || node.properties.arcCanvasData
        || readCanvasBackup(node, !canvasData && node.properties.arcCanvasData == null);
      if (existing) {
        if (!restoreCanvasFromText(existing)) resetCanvas(false);
      } else {
        resetCanvas(false);
      }

      const oldWidth = widthW?.callback;
      const oldHeight = heightW?.callback;
      if (widthW) widthW.callback = function () { oldWidth?.apply(this, arguments); scheduleResizePreserve(true); };
      if (heightW) heightW.callback = function () { oldHeight?.apply(this, arguments); scheduleResizePreserve(true); };
      const sizePoll = setInterval(() => {
        if (!visibleCanvasBox()) return;
        if (!applyConnectedSize(false)) syncCanvasSize(true);
        syncConnectedPrompts();
      }, 250);
      const sourcePoll = setInterval(() => {
        loadConnectedImage(false);
        applyConnectedSize(false);
        syncConnectedPrompts();
      }, 500);
      setTimeout(() => {
        loadConnectedImage(false);
        applyConnectedSize(true);
        syncConnectedPrompts();
      }, 100);

      const oldConnectionsChange = node.onConnectionsChange;
      node.onConnectionsChange = function () {
        oldConnectionsChange?.apply(this, arguments);
        setTimeout(() => {
          applyConnectedSize(true);
          loadConnectedImage(true);
          syncConnectedPrompts();
        }, 30);
      };

      const prevOnExecuted = node.onExecuted;
      node.onExecuted = function (message) {
        prevOnExecuted?.apply(this, arguments);
        try {
          const sizeMsg = message?.arc_size?.[0] || message?.arc_size;
          if (sizeMsg?.width && sizeMsg?.height) {
            lastArcSize = { width: sizeMsg.width, height: sizeMsg.height };
            applySizeFromValues(sizeMsg.width, sizeMsg.height, true);
          }
          const bgMsg = message?.arc_background?.[0] || message?.arc_background;
          if (bgMsg) {
            if (bgMsg.width && bgMsg.height) {
              lastArcSize = { width: bgMsg.width, height: bgMsg.height };
              applySizeFromValues(bgMsg.width, bgMsg.height, true);
            }
            if (bgMsg.clear === true || !bgMsg.image) {
              clearBackgroundToWhite();
              if (statusLabel) statusLabel.textContent = "No image signal — blank white canvas";
            } else {
              setBackgroundFromB64(bgMsg.image, `exec_${bgMsg.width}x${bgMsg.height}`);
            }
          }
          syncConnectedPrompts();
        } catch (_) {}
      };

      function onAnimaCanvasUpdate(event) {
        try {
          const detail = event?.detail ?? event;
          if (!detail) return;
          const nid = detail.node_id != null ? String(detail.node_id) : null;
          if (nid && String(node.id) !== nid) return;
          if (detail.width && detail.height) {
            lastArcSize = { width: detail.width, height: detail.height };
            applySizeFromValues(detail.width, detail.height, true);
          }
          if (detail.clear_background === true || detail.background == null) {
            clearBackgroundToWhite();
            if (statusLabel && !detail.paused) {
              statusLabel.textContent = "No image signal — blank white canvas";
            }
          } else if (detail.background) {
            setBackgroundFromB64(detail.background, `ws_${detail.width}x${detail.height}`);
          }
          syncConnectedPrompts();
          if (statusLabel && detail.paused) {
            if (detail.reason === "empty_mask") {
              statusLabel.textContent = "Paused — paint a region, then click Apply";
            } else {
              statusLabel.textContent = detail.background
                ? "Paused — paint regions, then click Apply"
                : "Paused — blank canvas. Paint or Apply";
            }
          }
        } catch (_) {}
      }
      if (app.api) app.api.addEventListener("anima.canvas.update", onAnimaCanvasUpdate);

      const oldSerialize = node.onSerialize;
      node.onSerialize = function (workflowNode) {
        saveData();
        writeSerializedValues(workflowNode);
        oldSerialize?.apply(this, arguments);
        if (workflowNode) {
          workflowNode.properties = workflowNode.properties || {};
          workflowNode.properties.animaPrompts = { ...node.properties.animaPrompts };
          workflowNode.properties.arcCanvasData = node.properties.arcCanvasData || canvasData?.value || "";
          workflowNode.properties.arcCanvasSizeVersion = CANVAS_SIZE_VERSION;
          writeSerializedValues(workflowNode);
        }
      };

      const oldConfigure = node.onConfigure;
      node.onConfigure = function () {
        const workflowInfo = arguments[0] || {};
        const workflowProperties = workflowInfo.properties || {};
        const hasWorkflowCanvasData = Object.prototype.hasOwnProperty.call(workflowProperties, "arcCanvasData");
        const workflowWidgetValues = Array.isArray(workflowInfo.widgets_values)
          ? workflowInfo.widgets_values
          : [];
        oldConfigure?.apply(this, arguments);
        node.properties = node.properties || {};
        node.properties.animaPrompts = node.properties.animaPrompts || {};
        removeLegacyInputs();
        syncPromptTextareas();
        const serializedCanvas = hasWorkflowCanvasData
          ? String(workflowProperties.arcCanvasData || "")
          : String(canvasData?.value || "");
        if (hasWorkflowCanvasData || !serializedCanvas) node.properties.arcCanvasData = serializedCanvas;
        // empty saved canvas: this workflow's own backup (unsaved paint); the shared old-style backup only when the
        // workflow carries no canvas value at all (see readCanvasBackup)
        const existingCanvas = serializedCanvas
          || readCanvasBackup(node, !hasWorkflowCanvasData && serializedCanvasMissing(workflowInfo));
        const payloadSize = canvasPayloadDimensions(existingCanvas);
        const workflowSizeVersion = Number(workflowProperties.arcCanvasSizeVersion || 0);
        const legacyWidgetSize = Number(workflowWidgetValues[0]) === 300
          && Number(workflowWidgetValues[1]) === 150;
        const legacyDefaultSize = workflowSizeVersion < CANVAS_SIZE_VERSION && (
          legacyWidgetSize
          || (Number(widthW?.value) === 300 && Number(heightW?.value) === 150)
          || (payloadSize?.width === 300 && payloadSize?.height === 150)
        );
        if (legacyDefaultSize) {
          if (widthW) widthW.value = 1024;
          if (heightW) heightW.value = 1024;
          resetCanvas(false);
        } else if (!restoreCanvasFromText(existingCanvas)) {
          resetCanvas(false);
        }
        requestAnimationFrame(fitCanvas);
      };
      const flushOnVisibilityChange = () => {
        if (document.visibilityState === "hidden") saveData();
        if (document.visibilityState === "visible") requestAnimationFrame(fitCanvas);
      };
      const onResizeVisible = () => {
        if (visibleCanvasBox()) requestAnimationFrame(fitCanvas);
      };
      window.addEventListener("blur", saveData);
      document.addEventListener("visibilitychange", flushOnVisibilityChange);
      canvasResizeObserver = new ResizeObserver(onResizeVisible);
      canvasResizeObserver.observe(canvasBox);
      syncPromptTextareas();

      node.addDOMWidget("anima_canvas_editor", "AnimaRegionalCanvasEditor", wrap, {
        serialize: false,
        hideOnZoom: false,
        getMinHeight: () => 980,
      });
      node.resizable = true;
      const targetSize = STANDARD_NODE_SIZE;
      if (node.size[0] < targetSize[0] || node.size[1] < targetSize[1]) {
        node.setSize([Math.max(node.size[0], targetSize[0]), Math.max(node.size[1], targetSize[1])]);
      }
      const originalResize = node.onResize;
      node.onResize = function () {
        originalResize?.apply(this, arguments);
        requestAnimationFrame(fitCanvas);
      };
      const originalRemoved = node.onRemoved;
      node.onRemoved = function () {
        saveData();
        clearInterval(sizePoll);
        clearInterval(sourcePoll);
        // the api listener and the undo snapshots would otherwise keep this node (and its canvases) alive
        if (app.api) app.api.removeEventListener("anima.canvas.update", onAnimaCanvasUpdate);
        history.length = 0;
        window.removeEventListener("blur", saveData);
        document.removeEventListener("visibilitychange", flushOnVisibilityChange);
        canvasResizeObserver?.disconnect?.();
        originalRemoved?.apply(this, arguments);
      };
      requestAnimationFrame(fitCanvas);
    };
  },
});
